# My Website

Hosted with GitHub Pages.

## Folder structure
- index.html : main page (must be named exactly this)
- style.css  : styling
- script.js  : JavaScript
- assets/images : put your images here
